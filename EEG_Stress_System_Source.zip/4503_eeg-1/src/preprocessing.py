def load_data(file_path):
    """Load data from a specified file path."""
    import pandas as pd
    return pd.read_csv(file_path)

def clean_data(data):
    """Clean the data by handling missing values and duplicates."""
    data = data.dropna()
    data = data.drop_duplicates()
    return data

def transform_data(data):
    """Transform the data as needed for analysis."""
    # Example transformation: normalize numerical columns
    for column in data.select_dtypes(include=['float64', 'int64']).columns:
        data[column] = (data[column] - data[column].mean()) / data[column].std()
    return data

def preprocess(file_path):
    """Main function to preprocess data."""
    data = load_data(file_path)
    data = clean_data(data)
    data = transform_data(data)
    return data