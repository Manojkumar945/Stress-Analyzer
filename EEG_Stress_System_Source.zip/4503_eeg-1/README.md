# 4503 EEG Project

## Overview
The 4503 EEG project is designed for analyzing EEG data. It includes various components for data preprocessing, analysis, and visualization. The project structure is organized to facilitate easy access to raw and processed data, as well as scripts and notebooks for exploration and testing.

## Project Structure
```
4503_eeg
├── data
│   ├── raw
│   └── processed
├── notebooks
│   └── 01-exploration.ipynb
├── src
│   ├── __init__.py
│   ├── preprocessing.py
│   ├── analysis.py
│   └── utils.py
├── scripts
│   └── runsteps
├── tests
│   └── test_analysis.py
├── .gitignore
├── pyproject.toml
└── requirements.txt
```

## Installation
To set up the project, clone the repository and install the required dependencies using pip:

```bash
pip install -r requirements.txt
```

## Usage
1. Place your raw EEG data files in the `data/raw` directory.
2. Use the `src/preprocessing.py` script to clean and transform the data.
3. Perform analysis using the functions in `src/analysis.py`.
4. Explore the data and visualize results in the Jupyter notebook located in `notebooks/01-exploration.ipynb`.
5. Run tests to ensure functionality using the scripts in the `tests` directory.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for details.