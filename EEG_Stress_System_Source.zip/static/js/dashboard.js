
// Dashboard Logic

// Global Intervals & State
let monitoringInterval = null;
let allReadings = [];
let clockInterval = null;
let pieChart = null;
let eegChart = null;
const maxPoints = 50;
let predictionCounts = { "Normal": 0, "Stress": 0, "Anxiety": 0 };

// Initialize
document.addEventListener('DOMContentLoaded', function () {
    restoreMonitoringState();
    startClock();

    // Search Listener
    const searchInput = document.getElementById('readingsSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            renderReadingsTable();
        });
    }
});

function handleLogout() {
    window.location.href = '/logout';
}

// Clock Logic
function startClock() {
    updateClock();
    clockInterval = setInterval(updateClock, 1000);
}

function updateClock() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true };
    const dateString = now.toLocaleDateString('en-US', options);
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        dateElement.textContent = dateString;
    }
}

// Patient Management
function toggleAddPatientModal() {
    const modal = document.getElementById('addPatientModal');
    modal.style.display = modal.style.display === 'none' ? 'flex' : 'none';
}

function handlePatientChange() {
    const select = document.getElementById('patientSelect');
    const patientName = select.options[select.selectedIndex].text;
    console.log("Selected patient:", patientName);
}

// Monitoring Logic

function startMonitoring() {
    const patientId = document.getElementById('patientSelect').value;
    if (!patientId) {
        alert("Please select a patient first.");
        return;
    }

    const formData = new FormData();
    formData.append('patient_id', patientId);

    fetch('/start_monitoring', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'started') {
                console.log('Monitoring started:', data);
                updateUIState(true);
                startPolling();
            } else {
                alert('Error starting monitoring: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(err => console.error("Start Error:", err));
}

function stopMonitoring() {
    fetch('/stop_monitoring', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            console.log('Monitoring stopped:', data);
            updateUIState(false, true);
            stopPolling();
        })
        .catch(err => console.error("Stop Error:", err));
}

function updateUIState(active, keepData = false) {
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const badge = document.getElementById('monitoringBadge');
    const badgeText = document.getElementById('monitoringText');
    const predictionText = document.getElementById('predictionText');

    if (startBtn) {
        startBtn.disabled = active;
        startBtn.style.opacity = active ? '0.6' : '1';
    }
    if (stopBtn) {
        stopBtn.disabled = !active;
        stopBtn.style.opacity = !active ? '0.6' : '1';
    }

    if (badge && badgeText) {
        if (active) {
            badge.style.background = '#d1fae5'; // Light green
            badge.style.color = '#059669'; // Green text
            badgeText.textContent = 'Active';
        } else {
            badge.style.background = '#e2e8f0'; // Light grey
            badge.style.color = '#64748b'; // Grey text
            badgeText.textContent = 'Inactive';
        }
    }

    if (!active && predictionText) {
        if (!keepData) {
            predictionText.textContent = 'None'; // Reset to default
            predictionText.style.color = '#2d3436';

            const sl = document.getElementById('stressLevelText');
            if (sl) sl.textContent = 'None';

            resetVitals();
            resetPieChart();
            resetEEGChart();
        }

        // Show last valid techniques if available (persists if keepData, clears if refresh)
        updateRelaxationTechniques(null);
    }
}

function restoreMonitoringState() {
    fetch('/get_status')
        .then(response => response.json())
        .then(data => {
            if (data.monitoring_active) {
                updateUIState(true);
                startPolling();
            } else {
                updateUIState(false);
            }
        })
        .catch(err => console.error("Status Error:", err));
}

function startPolling() {
    if (!monitoringInterval) {
        lastValidTechniquePred = null; // Reset persistence on new start
        updateStatus();
        // Poll every 4 seconds (slow updates)
        monitoringInterval = setInterval(updateStatus, 4000);
    }
}

function stopPolling() {
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
    }
}

let lastEmailSentTime = null;

function updateStatus() {
    fetch('/get_status')
        .then(response => response.json())
        .then(data => {
            if (!data.monitoring_active) {
                stopPolling();
                updateUIState(false);
                return;
            }

            updatePredictionDisplay(data.latest_prediction);
            updatePieChart(data.latest_prediction);

            // Update Stress Level
            const sl = document.getElementById('stressLevelText');
            if (sl) {
                sl.textContent = data.stress_level || '----';
                // Optional: Color code
                if (data.stress_level && data.stress_level.includes('High')) sl.style.color = '#d63031';
                else if (data.stress_level && data.stress_level.includes('Medium')) sl.style.color = '#e17055';
                else sl.style.color = '#636e72';
            }

            updateVitals(data.features);

            // Update EEG Metric
            const eegVal = document.getElementById('eegValue');
            if (eegVal) eegVal.textContent = data.features.eeg_val || '1024';

            // Update EEG Chart
            updateEEGChart(data.features.eeg_val);

            // Update Detail Result
            const elRes = document.getElementById('detailResult');
            if (elRes) {
                elRes.textContent = data.latest_prediction || 'None';
                if (data.latest_prediction) {
                    if (data.latest_prediction.includes('Stress')) elRes.style.color = '#dc3545';
                    else if (data.latest_prediction.includes('Anxiety')) elRes.style.color = '#ffc107';
                    else elRes.style.color = '#fd7e14';
                }
            }

            // Determine if a NEW alert (Email/WhatsApp) was sent
            let emailActuallySent = false;
            if (data.email_sent_time && data.email_sent_time !== lastEmailSentTime) {
                emailActuallySent = true;
                lastEmailSentTime = data.email_sent_time;

                // TRIGGER SOS ALARM (Visual) - DISABLED
                /*
                if (data.latest_prediction && ['Stress', 'Anxiety'].includes(data.latest_prediction)) {
                    showSOSAlert(data.caretaker_phone || "Registered Number");
                }
                */
            }

            // Add new reading
            addNewReading(data.features, data.latest_prediction, emailActuallySent);

            // Update Relaxation Techniques
            updateRelaxationTechniques(data.latest_prediction);

            // Handle song if needed (optional, depends on UI)
            if (data.current_song && data.current_song !== 'None') {
                // Logic to show playing song could go here
            }
        })
        .catch(err => console.error("Update Error:", err));
}

let lastValidTechniquePred = null;

function updateRelaxationTechniques(prediction) {
    const container = document.getElementById('relaxationTechniques');
    if (!container) return;

    let content = '';
    let pred = prediction ? prediction.toLowerCase() : 'none';

    // Persist last valid technique if prediction is invalid (e.g. stopped)
    if (['stress', 'anxiety', 'normal'].includes(pred)) {
        lastValidTechniquePred = pred;
    } else if (lastValidTechniquePred) {
        pred = lastValidTechniquePred;
    }

    // Update Therapy Page Status Indicator
    const therapyStatusEl = document.getElementById('therapyPagePrediction');
    if (therapyStatusEl) {
        therapyStatusEl.textContent = pred.charAt(0).toUpperCase() + pred.slice(1);
        if (pred === 'stress') therapyStatusEl.style.color = '#dc3545';
        else if (pred === 'anxiety') therapyStatusEl.style.color = '#ffc107';
        else therapyStatusEl.style.color = '#28a745';
    }

    if (pred === 'stress') {
        content = `
            <div style="text-align: center;">
                <h4 style="color: #dc3545; margin-bottom: 10px;">High Stress Detected</h4>
                <p style="font-size: 16px; font-weight: 500;">Recommended: 4-7-8 Breathing</p>
                <p>1. Inhale quietly through the nose for <b>4 seconds</b>.</p>
                <p>2. Hold the breath for <b>7 seconds</b>.</p>
                <p>3. Exhale forcefully through the mouth for <b>8 seconds</b>.</p>
            </div>
        `;
    } else if (pred === 'anxiety') {
        content = `
            <div style="text-align: center;">
                <h4 style="color: #ffc107; margin-bottom: 10px;">Anxiety Detected</h4>
                <p style="font-size: 16px; font-weight: 500;">Recommended: Box Breathing</p>
                <p>1. Inhale for <b>4 seconds</b>.</p>
                <p>2. Hold for <b>4 seconds</b>.</p>
                <p>3. Exhale for <b>4 seconds</b>.</p>
                <p>4. Hold for <b>4 seconds</b>.</p>
            </div>
        `;
    } else if (pred === 'normal') {
        content = `
            <div style="text-align: center; color: #28a745;">
                <h4 style="margin-bottom: 15px; font-size: 22px;"><i class="fas fa-smile"></i> State is Normal</h4>
                <p style="font-size: 18px; font-weight: 600; color: #2d3436;">There is No Therapy needed</p>
            </div>
        `;
    } else {
        content = '<p style="color: #666;">Waiting for monitoring data...</p>';
    }

    container.innerHTML = content;

    // Song Option Visibility Logic - Always Visible
    const musicPlayerSection = document.getElementById('musicPlayer');
    if (musicPlayerSection) {
        musicPlayerSection.style.display = 'block';
    }
}

function updatePredictionDisplay(prediction) {
    const text = document.getElementById('predictionText');
    if (!text) return;

    text.textContent = prediction.toUpperCase();

    // Update color based on prediction
    if (prediction.toLowerCase() === 'stress') {
        text.style.color = '#dc3545'; // Red
    } else if (prediction.toLowerCase() === 'anxiety') {
        text.style.color = '#ffc107'; // Yellow/Orange
    } else {
        text.style.color = '#28a745'; // Green
    }
}

function updateVitals(features) {
    document.getElementById('heartRate').textContent = features.heart_rate ? features.heart_rate.toFixed(1) : '0.0';
    document.getElementById('meanVal').textContent = features.mean_val ? features.mean_val.toFixed(2) : '0.00';
    document.getElementById('stdVal').textContent = features.std_val ? features.std_val.toFixed(2) : '0.00';
    document.getElementById('entropy').textContent = features.entropy ? features.entropy.toFixed(2) : '0.00';

    // Update Detailed Metrics Card
    const elMean = document.getElementById('detailMeanVal');
    if (elMean) elMean.textContent = features.mean_val ? features.mean_val.toFixed(2) : '--';

    const elStd = document.getElementById('detailStdVal');
    if (elStd) elStd.textContent = features.std_val ? features.std_val.toFixed(2) : '--';

    const elPeak = document.getElementById('detailPeakAmp');
    if (elPeak) elPeak.textContent = features.peak_amp ? features.peak_amp.toFixed(2) : '--';

    const elHeart = document.getElementById('detailHeartRate');
    if (elHeart) elHeart.textContent = features.heart_rate ? features.heart_rate.toFixed(1) : '--';

    const elRR = document.getElementById('detailRRVar');
    if (elRR) elRR.textContent = features.rr_var ? features.rr_var.toFixed(2) : '--';

    const elEnt = document.getElementById('detailEntropy');
    if (elEnt) elEnt.textContent = features.entropy ? features.entropy.toFixed(2) : '--';
}

function resetVitals() {
    document.getElementById('heartRate').textContent = '75';
    document.getElementById('meanVal').textContent = '0.55';
    document.getElementById('stdVal').textContent = '0.13';
    document.getElementById('entropy').textContent = '0.72';
}

function addNewReading(features, prediction, emailSent = false) {
    const now = new Date();
    const reading = {
        id: allReadings.length + 1,
        timestamp: now.toLocaleDateString(),
        time: now.toLocaleTimeString(),
        eeg_value: features.eeg_val ? features.eeg_val : '1024',
        prediction: prediction || '----',
        email_sent: emailSent, // Store email status
        heart_rate: features.heart_rate ? features.heart_rate.toFixed(1) : '84.7',
        mean_val: features.mean_val ? features.mean_val.toFixed(2) : '459.22',
        std_val: features.std_val ? features.std_val.toFixed(2) : '5.42',
        peak_amp: features.peak_amp ? features.peak_amp.toFixed(2) : '464.92'
    };

    allReadings.unshift(reading); // Add to top
    renderReadingsTable();
}

// Refactored to render Stress Events List instead of Table
function renderReadingsTable() {
    // Note: Function name kept to avoid breaking calls in addNewReading, but it renders the list now.
    const listContainer = document.getElementById('stressEventsList');
    if (!listContainer) return;

    listContainer.innerHTML = '';

    // Filter to show ONLY events where an Alert was Sent (Email Sent) AND result is valid
    const significantEvents = allReadings.filter(r => r.email_sent === true && r.prediction !== '----');

    if (significantEvents.length === 0) {
        listContainer.innerHTML = '<div style="padding: 20px; text-align: center; color: #666;">No alert events recorded yet.</div>';
        return;
    }

    // Get current patient name
    const patientSelect = document.getElementById('patientSelect');
    const patientName = patientSelect && patientSelect.options[patientSelect.selectedIndex].text !== 'Select a patient...'
        ? patientSelect.options[patientSelect.selectedIndex].text
        : 'manoj';

    significantEvents.slice(0, 50).forEach(r => {
        const item = document.createElement('div');
        item.className = 'event-item';

        const prediction = r.prediction ? r.prediction.toUpperCase() : 'UNKNOWN';

        const alertBadge = `
            <div class="alert-badge">
                <i class="fas fa-envelope"></i> Alert Sent
            </div>
        `;

        item.innerHTML = `
            <div class="event-info">
                <div class="event-title">
                    <strong>${patientName}</strong> – ${prediction}
                </div>
                <div class="event-time">
                    ${r.timestamp} ${r.time}
                </div>
            </div>
            ${alertBadge}
        `;

        listContainer.appendChild(item);
    });
}

// Expanded Music Library
// Expanded Music Library with Tamil Songs
const musicLibrary = {
    'calm': [
        // Calm/Relaxing (Instrumental/Gentle)
        { name: "Weightless - Marconi Union", url: "https://youtu.be/UfcAVejslrU?si=8cSSpqTmoVIkRT5a" },
        { name: "Rain Sounds for Sleep", url: "https://www.youtube.com/watch?v=mPZkdNFkNps" },
        { name: "Tibetan Singing Bowls", url: "https://youtu.be/0-g1zPWQPHk?si=TvQAf5JvltVcPKLC" },
        { name: "Yung Kai", url: "https://youtu.be/4adZ7AguVcw?si=3YHJVPESJV9nHYev" },
        { name: "Relaxing Guitar for Stress Relief", url: "https://youtu.be/f-i_nJLG2Is?si=MvF_dmKRQ6KwpG9K" },
    ],
    'melody': [
        // Tamil Melodies (Instrumental/Covers for Embedding)
        { name: "Munbe Vaa (Instrumental)", url: "https://youtu.be/5683ZiVRs7Y?si=6vvQpkCC8MiRRsnU" },
        { name: "3 - Moonu (Violin BGM)", url: "https://youtu.be/bZ-Z-b3Yzgk?si=ENDVGG6uI84WNG8d" },
        { name: "Nenjukkul Peidhidum (Guitar)", url: "https://youtu.be/C4NJMjVQQrU?si=wAnjbtEzjx-mAut8" },
        { name: "Ilaiyaraja Instrumental BGM", url: "https://youtu.be/I5_BuHWAlnw?si=PU1miNDcDNtwF87S" },
        { name: "Chill Mode", url: "https://youtu.be/G7qzeD_sq4s?si=ESYEaqBw0FmSmTzk" }
    ],
    'vibe': [
        // Tamil Vibe (Instrumental/Covers for Embedding)
        { name: "Arabic Kuthu (Instrumental)", url: "https://youtu.be/8FAUEv_E_xQ?si=VwpTr5fjk5Judwc7" },
        { name: "Vaathi Coming (Beat Cover)", url: "https://youtu.be/fRD_3vJagxk?si=ESSP0te4tE-CGc3N" },
        { name: "Chellamma (Instrumental)", url: "https://youtu.be/DV7nV9W7y-0?si=FTbIb3zfTkbVYIJD" },
        { name: "Party Vibe Songs", url: "https://youtu.be/EnkOl4cHQjk?si=sv_VV_vpKcEO6nFR" },
        { name: "Kanimaa", url: "https://youtu.be/yG2MoXdFB34?si=91Hdd9ShIDXKA052" }
    ]
};

// Fallback if no specific mood selected
const allSongs = [...musicLibrary.calm, ...musicLibrary.melody, ...musicLibrary.vibe];

let sensorySettings = {
    light: null,
    music: null,
    aroma: null
};

// Select Sensory Option
function selectSensory(btn, type, value) {
    // Update State
    sensorySettings[type] = value;

    // Update UI (Active Class)
    const buttons = btn.parentElement.querySelectorAll('.sensory-btn');
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

// Activate Ambience
function activateAmbience() {
    const statusEl = document.getElementById('ambienceStatus');

    // Simulate activation delay
    const btn = document.querySelector('button[onclick="activateAmbience()"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Activating...';
    btn.disabled = true;

    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.disabled = false;

        if (statusEl) {
            statusEl.style.opacity = '1';
            setTimeout(() => { statusEl.style.opacity = '0'; }, 5000);
        }

        // Auto-play music if selected
        if (sensorySettings.music) {
            playTherapy(sensorySettings.music);
        }

        // Log to console (Simulation of IoT call)
        console.log("Activating Environment:", sensorySettings);

    }, 1000);
}

function playTherapy(mood = null) {
    // Determine pool of songs
    let pool = allSongs;

    // Use argument mood, or stored setting, or default
    const targetMood = mood || sensorySettings.music;

    if (targetMood && musicLibrary[targetMood]) {
        pool = musicLibrary[targetMood];
    }

    // Pick a random song
    const song = pool[Math.floor(Math.random() * pool.length)];

    // Parse Video ID for Thumbnail
    let videoId = null;
    try {
        const urlStr = song.url.trim();
        if (urlStr.includes("v=")) {
            videoId = urlStr.split("v=")[1].split("&")[0];
        } else if (urlStr.includes("youtu.be/")) {
            videoId = urlStr.split("youtu.be/")[1].split("?")[0];
        }
    } catch (e) { console.log("Video ID parse error", e); }

    // Update UI
    const songNameDisplay = document.getElementById('currentSongName');
    if (songNameDisplay && videoId) {
        songNameDisplay.innerHTML = `
            <div style="background: #f1f3f5; padding: 15px; border-radius: 12px; border: 1px solid #dee2e6;">
                <p style="margin-bottom: 10px; font-weight: 600; color: #333; display: flex; justify-content: space-between; align-items: center;">
                    <span><i class="fas fa-play-circle" style="color: #0984e3;"></i> Now Playing: ${song.name}</span>
                    <a href="${song.url}" target="_blank" style="font-size: 12px; color: #0984e3; text-decoration: none;">
                        <i class="fas fa-external-link-alt"></i> Open in YouTube
                    </a>
                </p>
                <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 10px; background: #000;">
                    <iframe 
                        src="https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&origin=${window.location.origin}" 
                        style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen
                        title="${song.name}">
                    </iframe>
                </div>
            </div>
        `;
    } else if (songNameDisplay) {
        // Fallback
        songNameDisplay.innerHTML = `Playing: <a href="${song.url}" target="_blank">${song.name}</a>`;
        window.open(song.url, '_blank');
    }
}

function exportToCSV() {
    if (allReadings.length === 0) {
        alert("No data to export.");
        return;
    }

    const headers = ["ID", "Timestamp", "Time", "EEG Value", "Prediction", "Heart Rate", "Mean Value", "Std Deviation", "Peak Amplitude"];
    const rows = allReadings.map(r => [
        r.id,
        r.timestamp,
        r.time,
        r.eeg_value,
        r.prediction,
        r.heart_rate,
        r.mean_val,
        r.std_val,
        r.peak_amp
    ]);

    let csvContent = "data:text/csv;charset=utf-8,"
        + headers.join(",") + "\n"
        + rows.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "eeg_readings.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// ==========================================
// PIE CHART LOGIC (Session Distribution)
// ==========================================
function initPieChart() {
    const ctx = document.getElementById('predictionPieChart');
    if (!ctx) return;

    pieChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Normal', 'Stress', 'Anxiety'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: ['#28a745', '#dc3545', '#ffc107'],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { boxWidth: 12, font: { size: 10 } }
                }
            },
            cutout: '70%' // Thin donut
        }
    });
}

function updatePieChart(prediction) {
    if (!pieChart) initPieChart();
    if (!prediction || prediction === 'None') return;

    // Normalize prediction string
    let key = prediction.trim();
    if (key.includes('Normal')) key = 'Normal';
    else if (key.includes('Stress') && !key.includes('Anxiety')) key = 'Stress';
    else if (key.includes('Anxiety')) key = 'Anxiety';
    else return; // Unknown

    // Increment count
    predictionCounts[key]++;

    // Update Chart
    if (pieChart) {
        pieChart.data.datasets[0].data = [
            predictionCounts['Normal'],
            predictionCounts['Stress'],
            predictionCounts['Anxiety']
        ];
        pieChart.update();
    }
}

function resetPieChart() {
    predictionCounts = { "Normal": 0, "Stress": 0, "Anxiety": 0 };
    if (pieChart) {
        pieChart.data.datasets[0].data = [0, 0, 0];
        pieChart.update();
    }
}

// ==========================================
// EEG TIMELINE CHART LOGIC
// ==========================================
function initEEGChart() {
    const ctx = document.getElementById('eegChart');
    if (!ctx) return;

    eegChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'EEG Signal',
                data: [],
                borderColor: '#007bff',
                borderWidth: 2,
                fill: false,
                tension: 0.3,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: '#333' }, grid: { color: '#eee' } },
                y: { ticks: { color: '#333' }, grid: { color: '#eee' } }
            },
            animation: { duration: 0 } // Performance
        }
    });
}

function updateEEGChart(value) {
    if (!eegChart) initEEGChart();
    if (!eegChart) return;

    const now = new Date();
    const timeStr = now.toLocaleTimeString();

    eegChart.data.labels.push(timeStr);
    eegChart.data.datasets[0].data.push(value || 0);

    if (eegChart.data.labels.length > maxPoints) {
        eegChart.data.labels.shift();
        eegChart.data.datasets[0].data.shift();
    }
    eegChart.update();
}

function resetEEGChart() {
    if (eegChart) {
        eegChart.data.labels = [];
        eegChart.data.datasets[0].data = [];
        eegChart.update();
    }
}

// ==========================================
// SOS MODAL LOGIC (New)
// ==========================================
function showSOSAlert(phoneNumber) {
    // Create Modal HTML dynamically if it doesn't exist
    if (!document.getElementById('sosModal')) {
        const modalHtml = `
        <div id="sosModal" style="display:none; position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.8); align-items: center; justify-content: center; backdrop-filter: blur(5px);">
            <div style="background-color: #fff; margin: auto; padding: 40px; border: 5px solid #ff4757; width: 90%; max-width: 500px; border-radius: 20px; text-align: center; box-shadow: 0 0 50px rgba(255, 71, 87, 0.8); animation: pulse-red 1.5s infinite;">
                <div style="font-size: 70px; color: #ff4757; margin-bottom: 20px;">
                    <i class="fas fa-biohazard fa-spin" style="animation-duration: 3s;"></i>
                </div>
                <h1 style="color: #ff4757; font-size: 40px; margin-bottom: 10px; font-weight: 800; text-transform: uppercase;">SOS ALERT</h1>
                <h2 style="color: #2f3542; margin-bottom: 5px; font-size: 24px;">Abnormal Stress Detected!</h2>
                
                <p style="font-size: 16px; color: #747d8c; margin-bottom: 30px;">
                    Instant alert sent via WhatsApp to Caretaker.
                </p>
                
                <div style="background: #ffeaa7; padding: 20px; border-radius: 15px; margin-bottom: 30px; border: 2px dashed #fdcb6e;">
                    <p style="margin:0; font-weight: bold; color: #d35400; font-size: 14px; text-transform: uppercase;">Caretaker Contact</p>
                    <p style="margin:5px 0 0 0; font-size: 28px; font-weight: 900; color: #2d3436; letter-spacing: 1px;" id="sosPhoneDisplay">
                        ${phoneNumber}
                    </p>
                </div>

                <div class="sos-actions" style="display: flex; gap: 15px; justify-content: center;">
                    <button onclick="closeSOS()" style="padding: 15px 40px; background: #dfe4ea; color: #2f3542; border: none; border-radius: 50px; font-weight: bold; cursor: pointer; font-size: 16px; transition: all 0.3s;">
                        Dismiss
                    </button>
                    <a href="tel:${phoneNumber}" style="padding: 15px 40px; background: #ff4757; color: white; border: none; border-radius: 50px; font-weight: bold; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; box-shadow: 0 10px 20px rgba(255, 71, 87, 0.3);">
                        <i class="fas fa-phone-alt"></i> CALL NOW
                    </a>
                </div>
            </div>
        </div>
        <style>
            @keyframes pulse-red {
                0% { box-shadow: 0 0 0 0 rgba(255, 71, 87, 0.7); transform: scale(1); }
                50% { transform: scale(1.02); }
                70% { box-shadow: 0 0 0 20px rgba(255, 71, 87, 0); }
                100% { box-shadow: 0 0 0 0 rgba(255, 71, 87, 0); transform: scale(1); }
            }
        </style>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    // Update Phone
    const phoneDisplay = document.getElementById('sosPhoneDisplay');
    if (phoneDisplay) phoneDisplay.textContent = phoneNumber;

    // Show Modal
    const modal = document.getElementById('sosModal');
    modal.style.display = 'flex';
}

function closeSOS() {
    const modal = document.getElementById('sosModal');
    if (modal) modal.style.display = 'none';
}
