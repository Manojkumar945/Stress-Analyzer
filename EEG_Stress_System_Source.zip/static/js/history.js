// History Page JavaScript
let timelineChart = null;
let allReadings = [];
let filteredReadings = [];
let currentPage = 1;
const readingsPerPage = 100;
let isAutoRefreshEnabled = false;
let scrollPosition = 0;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function () {
    initChart();
    loadHistory();
    loadSessions();

    // Store scroll position before refresh
    const tableContainer = document.querySelector('.table-container');
    if (tableContainer) {
        tableContainer.addEventListener('scroll', function () {
            scrollPosition = tableContainer.scrollTop;
        });
    }

    // Auto-refresh every 5 seconds if monitoring is active (but preserve scroll and page)
    setInterval(() => {
        if (isAutoRefreshEnabled) {
            // Save current page before refresh
            const savedPage = currentPage;
            const hours = document.getElementById('hoursFilter').value;
            const session = document.getElementById('sessionFilter').value;

            const url = `/api/detailed_history?hours=${hours}${session ? `&session_id=${session}` : ''}&limit=10000`;

            // Save current scroll position
            const tableContainer = document.querySelector('.table-container');
            if (tableContainer) {
                scrollPosition = tableContainer.scrollTop;
            }

            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    allReadings = data.readings || [];
                    allReadings.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
                    filteredReadings = [...allReadings];

                    // Update chart
                    updateChart(allReadings);

                    // Update stats
                    updateStats(data);

                    // Restore page
                    currentPage = savedPage;
                    displayTable();

                    // Restore scroll position
                    setTimeout(() => {
                        if (tableContainer && scrollPosition > 0) {
                            tableContainer.scrollTop = scrollPosition;
                        }
                    }, 100);
                })
                .catch(error => {
                    console.error('Error auto-refreshing history:', error);
                });
        }
    }, 5000);
});

// Initialize timeline chart
// Initialize timeline chart
function initChart() {
    const canvas = document.getElementById('timelineChart');
    if (!canvas) {
        console.log('Timeline chart canvas not found, skipping chart initialization.');
        return;
    }
    const ctx = canvas.getContext('2d');
    timelineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'EEG Value',
                data: [],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 1,
                pointHoverRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        title: function (context) {
                            return context[0].label;
                        },
                        label: function (context) {
                            return 'EEG Value: ' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'EEG Value'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time'
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45,
                        maxTicksLimit: 20
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    });
}

// Load history data
function loadHistory() {
    const hours = document.getElementById('hoursFilter').value;
    const session = document.getElementById('sessionFilter').value;

    const url = `/api/detailed_history?hours=${hours}${session ? `&session_id=${session}` : ''}&limit=10000`;

    // Save current scroll position
    const tableContainer = document.querySelector('.table-container');
    if (tableContainer) {
        scrollPosition = tableContainer.scrollTop;
    }

    // Show loading state
    document.getElementById('readingsTableBody').innerHTML =
        '<tr><td colspan="9" class="loading">Loading history data...</td></tr>';

    // Disable refresh button during loading
    const refreshBtn = document.querySelector('button[onclick="loadHistory()"]');
    if (refreshBtn) {
        refreshBtn.disabled = true;
        refreshBtn.textContent = '🔄 Loading...';
    }

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            allReadings = data.readings || [];
            // Sort by timestamp to ensure chronological order
            allReadings.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
            filteredReadings = [...allReadings];

            // Update chart first
            updateChart(allReadings);

            // Update stats
            updateStats(data);

            // Update table
            currentPage = 1;
            displayTable();

            // Restore scroll position after table is rendered
            setTimeout(() => {
                const tableContainer = document.querySelector('.table-container');
                if (tableContainer && scrollPosition > 0) {
                    tableContainer.scrollTop = scrollPosition;
                }
            }, 200);

            // Load sessions dropdown
            loadSessions();

            // Enable auto-refresh after initial load
            isAutoRefreshEnabled = true;
        })
        .catch(error => {
            console.error('Error loading history:', error);
            document.getElementById('readingsTableBody').innerHTML =
                '<tr><td colspan="9" class="loading">Error loading history data: ' + error.message + '</td></tr>';
        })
        .finally(() => {
            // Re-enable refresh button
            if (refreshBtn) {
                refreshBtn.disabled = false;
                refreshBtn.textContent = '🔄 Refresh';
            }
        });
}

// Load available sessions
function loadSessions() {
    fetch('/api/history?hours=168')
        .then(response => response.json())
        .then(data => {
            const sessions = new Set();
            if (data.history) {
                data.history.forEach(item => {
                    if (item.session_id) {
                        sessions.add(item.session_id);
                    }
                });
            }

            const select = document.getElementById('sessionFilter');
            const currentValue = select.value;
            select.innerHTML = '<option value="">All Sessions</option>';

            sessions.forEach(session => {
                const option = document.createElement('option');
                option.value = session;
                option.textContent = session;
                select.appendChild(option);
            });

            if (currentValue) {
                select.value = currentValue;
            }
        })
        .catch(error => console.error('Error loading sessions:', error));
}

// Update statistics
function updateStats(data) {
    const readings = data.readings || filteredReadings;
    const total = readings.length;

    document.getElementById('totalReadings').textContent = total.toLocaleString();

    if (data.time_range && data.time_range.start && data.time_range.end) {
        const start = new Date(data.time_range.start);
        const end = new Date(data.time_range.end);
        const duration = Math.round((end - start) / 1000 / 60); // minutes
        document.getElementById('timeRange').textContent = duration + ' min';
    } else {
        document.getElementById('timeRange').textContent = '--';
    }

    if (total > 0) {
        const avg = readings.reduce((sum, r) => sum + r.eeg_value, 0) / total;
        document.getElementById('avgValue').textContent = avg.toFixed(2);

        const hours = parseFloat(document.getElementById('hoursFilter').value) || 24;
        const rate = total / hours;
        document.getElementById('readingsRate').textContent = rate.toFixed(1) + '/hour';
    } else {
        document.getElementById('avgValue').textContent = '--';
        document.getElementById('readingsRate').textContent = '--';
    }

    document.getElementById('totalCount').textContent = total.toLocaleString();
}

// Update timeline chart
function updateChart(readings) {
    if (!timelineChart) return;

    if (!readings || readings.length === 0) {
        timelineChart.data.labels = [];
        timelineChart.data.datasets[0].data = [];
        timelineChart.update();
        return;
    }

    // Limit to last 1000 points for performance
    const displayReadings = readings.length > 1000 ? readings.slice(-1000) : readings;

    const labels = displayReadings.map(r => {
        const d = new Date(r.timestamp);
        return d.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    });

    const values = displayReadings.map(r => r.eeg_value);

    timelineChart.data.labels = labels;
    timelineChart.data.datasets[0].data = values;
    timelineChart.update('none');
}

// Display table with pagination
function displayTable() {
    const tbody = document.getElementById('readingsTableBody');
    const start = (currentPage - 1) * readingsPerPage;
    const end = start + readingsPerPage;
    const pageReadings = filteredReadings.slice(start, end);

    if (pageReadings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="loading">No readings found</td></tr>';
        return;
    }

    tbody.innerHTML = pageReadings.map((reading, index) => {
        const timestamp = new Date(reading.timestamp);
        const dateStr = timestamp.toLocaleDateString('en-US');
        const timeStr = timestamp.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        // Get prediction data - handle both direct prediction object and nested structure
        let prediction = '--';
        let heartRate = '--';
        let meanVal = '--';
        let stdVal = '--';
        let peakAmp = '--';

        if (reading.prediction) {
            if (typeof reading.prediction === 'string') {
                prediction = reading.prediction;
            } else if (reading.prediction.prediction) {
                prediction = reading.prediction.prediction;
            }

            if (reading.prediction.heart_rate !== undefined && reading.prediction.heart_rate !== null) {
                heartRate = reading.prediction.heart_rate.toFixed(1) + ' bpm';
            }
            if (reading.prediction.mean_val !== undefined && reading.prediction.mean_val !== null) {
                meanVal = reading.prediction.mean_val.toFixed(2);
            }
            if (reading.prediction.std_val !== undefined && reading.prediction.std_val !== null) {
                stdVal = reading.prediction.std_val.toFixed(2);
            }
            if (reading.prediction.peak_amp !== undefined && reading.prediction.peak_amp !== null) {
                peakAmp = reading.prediction.peak_amp.toFixed(2);
            }
        }

        const predictionClass = prediction === 'anxiety' ? 'anxiety' :
            prediction === 'stress' ? 'stress' :
                prediction === 'normal' ? 'normal' : '';

        const predictionBadge = prediction !== '--' ?
            '<span class="prediction-badge ' + predictionClass + '">' + prediction.toUpperCase() + '</span>' :
            '--';

        return '<tr>' +
            '<td>' + (start + index + 1) + '</td>' +
            '<td>' + dateStr + '</td>' +
            '<td>' + timeStr + '</td>' +
            '<td><strong>' + reading.eeg_value.toFixed(2) + '</strong></td>' +
            '<td>' + predictionBadge + '</td>' +
            '<td>' + heartRate + '</td>' +
            '<td>' + meanVal + '</td>' +
            '<td>' + stdVal + '</td>' +
            '<td>' + peakAmp + '</td>' +
            '</tr>';
    }).join('');

    // Update pagination
    updatePagination();
}

// Update pagination controls
function updatePagination() {
    const totalPages = Math.ceil(filteredReadings.length / readingsPerPage);
    document.getElementById('pageInfo').textContent = `Page ${currentPage} of ${totalPages}`;
    document.getElementById('prevPage').disabled = currentPage === 1;
    document.getElementById('nextPage').disabled = currentPage >= totalPages;
    document.getElementById('showingCount').textContent =
        filteredReadings.length > 0 ?
            ((currentPage - 1) * readingsPerPage + 1).toLocaleString() +
            ' - ' +
            Math.min(currentPage * readingsPerPage, filteredReadings.length).toLocaleString() :
            '0';
}

// Filter table
function filterTable() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();

    if (!searchTerm) {
        filteredReadings = [...allReadings];
    } else {
        filteredReadings = allReadings.filter(reading => {
            const timestamp = new Date(reading.timestamp).toLocaleString().toLowerCase();
            const value = reading.eeg_value.toString().toLowerCase();
            const prediction = reading.prediction ? reading.prediction.prediction : '';
            return timestamp.includes(searchTerm) ||
                value.includes(searchTerm) ||
                prediction.toLowerCase().includes(searchTerm);
        });
    }

    currentPage = 1;
    displayTable();
}

// Pagination functions
function previousPage() {
    if (currentPage > 1) {
        currentPage--;
        displayTable();
        document.getElementById('readingsTable').scrollIntoView({ behavior: 'smooth' });
    }
}

function nextPage() {
    const totalPages = Math.ceil(filteredReadings.length / readingsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        displayTable();
        document.getElementById('readingsTable').scrollIntoView({ behavior: 'smooth' });
    }
}

// Export data to CSV
function exportData() {
    if (filteredReadings.length === 0) {
        alert('No data to export');
        return;
    }

    const headers = ['Index', 'Timestamp', 'Date', 'Time', 'EEG Value', 'Prediction',
        'Heart Rate', 'Mean Value', 'Std Deviation', 'Peak Amplitude',
        'RR Variance', 'Entropy'];

    const csvRows = [headers.join(',')];

    filteredReadings.forEach((reading, index) => {
        const timestamp = new Date(reading.timestamp);
        const dateStr = timestamp.toLocaleDateString('en-US');
        const timeStr = timestamp.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        const prediction = reading.prediction || {};
        const row = [
            index + 1,
            reading.timestamp,
            dateStr,
            timeStr,
            reading.eeg_value.toFixed(2),
            prediction.prediction || '',
            prediction.heart_rate ? prediction.heart_rate.toFixed(1) : '',
            prediction.mean_val ? prediction.mean_val.toFixed(2) : '',
            prediction.std_val ? prediction.std_val.toFixed(2) : '',
            prediction.peak_amp ? prediction.peak_amp.toFixed(2) : '',
            prediction.rr_var ? prediction.rr_var.toFixed(2) : '',
            prediction.entropy ? prediction.entropy.toFixed(2) : ''
        ];
        csvRows.push(row.join(','));
    });

    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eeg_history_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
}

