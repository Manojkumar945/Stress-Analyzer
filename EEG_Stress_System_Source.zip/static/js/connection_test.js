// Connection Test JavaScript
let continuousTestInterval = null;

// Test EEG board connection
function testConnection() {
    const statusDisplay = document.getElementById('connectionStatus');
    const detailsPanel = document.getElementById('connectionDetails');
    
    statusDisplay.className = 'status-display testing';
    statusDisplay.innerHTML = `
        <div class="status-icon">⏳</div>
        <div class="status-text">Testing connection...</div>
    `;
    detailsPanel.style.display = 'none';
    
    fetch('/api/test_connection')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'connected') {
                statusDisplay.className = 'status-display success';
                statusDisplay.innerHTML = `
                    <div class="status-icon">✅</div>
                    <div class="status-text">EEG Board Connected Successfully!</div>
                    <div style="margin-top: 10px; font-size: 0.9em;">EEG Value: ${data.eeg_value}</div>
                `;
                
                // Show details
                detailsPanel.style.display = 'block';
                document.getElementById('statusValue').textContent = 'Connected';
                document.getElementById('statusValue').style.color = '#28a745';
                document.getElementById('endpointValue').textContent = data.endpoint || 'https://iotcloud22.in/4503_eeg/light.json';
                document.getElementById('eegValue').textContent = data.eeg_value.toFixed(2);
                document.getElementById('lastUpdate').textContent = new Date(data.timestamp).toLocaleString();
                document.getElementById('rawData').textContent = JSON.stringify(data.data_received, null, 2);
            } else {
                statusDisplay.className = 'status-display error';
                statusDisplay.innerHTML = `
                    <div class="status-icon">❌</div>
                    <div class="status-text">EEG Board Not Connected</div>
                    <div style="margin-top: 10px; font-size: 0.9em;">${data.message || 'Connection failed'}</div>
                `;
                
                // Show error details
                detailsPanel.style.display = 'block';
                document.getElementById('statusValue').textContent = 'Not Connected';
                document.getElementById('statusValue').style.color = '#dc3545';
                document.getElementById('endpointValue').textContent = data.endpoint || 'https://iotcloud22.in/4503_eeg/light.json';
                document.getElementById('eegValue').textContent = 'N/A';
                document.getElementById('lastUpdate').textContent = new Date().toLocaleString();
                document.getElementById('rawData').textContent = data.message || 'No data received';
            }
        })
        .catch(error => {
            statusDisplay.className = 'status-display error';
            statusDisplay.innerHTML = `
                <div class="status-icon">❌</div>
                <div class="status-text">EEG Board Not Connected</div>
                <div style="margin-top: 10px; font-size: 0.9em;">${error.message || 'Connection error occurred'}</div>
            `;
            
            detailsPanel.style.display = 'block';
            document.getElementById('statusValue').textContent = 'Not Connected';
            document.getElementById('statusValue').style.color = '#dc3545';
            document.getElementById('endpointValue').textContent = 'https://iotcloud22.in/4503_eeg/light.json';
            document.getElementById('eegValue').textContent = 'N/A';
            document.getElementById('lastUpdate').textContent = new Date().toLocaleString();
            document.getElementById('rawData').textContent = error.message || 'Connection error';
        });
}

// Start continuous testing
function startContinuousTest() {
    if (continuousTestInterval) {
        return; // Already running
    }
    
    testConnection(); // Test immediately
    continuousTestInterval = setInterval(testConnection, 5000); // Test every 5 seconds
    
    const statusDisplay = document.getElementById('connectionStatus');
    statusDisplay.innerHTML += '<div style="margin-top: 10px; font-size: 0.9em; color: #856404;">🔄 Continuous testing active (every 5 seconds)</div>';
}

// Stop continuous testing
function stopContinuousTest() {
    if (continuousTestInterval) {
        clearInterval(continuousTestInterval);
        continuousTestInterval = null;
        
        const statusDisplay = document.getElementById('connectionStatus');
        const currentHTML = statusDisplay.innerHTML;
        statusDisplay.innerHTML = currentHTML.replace(/🔄 Continuous testing active.*/, '');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Auto-test on page load
    testConnection();
});

