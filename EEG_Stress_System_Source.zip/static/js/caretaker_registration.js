// Caretaker Registration JavaScript

// Load caretakers on page load
document.addEventListener('DOMContentLoaded', function () {
    loadCaretakers();

    // Handle form submission
    document.getElementById('registrationForm').addEventListener('submit', function (e) {
        e.preventDefault();
        registerCaretaker();
    });
});

// Register new caretaker
function registerCaretaker() {
    const form = document.getElementById('registrationForm');
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirm_password').value.trim();
    const email = document.getElementById('email').value.trim().toLowerCase();
    const name = document.getElementById('name').value.trim();

    if (password !== confirmPassword) {
        const messageEl = document.getElementById('message');
        messageEl.className = 'message error';
        messageEl.textContent = '❌ Passwords do not match!';
        messageEl.style.display = 'block';
        return;
    }

    const formData = {
        name: name,
        username: email.split('@')[0], // Auto-generate username from email
        password: password,
        mobile_number: "0000000000", // Placeholder as field was removed from UI
        email: email
    };

    // Show loading
    const messageEl = document.getElementById('message');
    messageEl.className = 'message';
    messageEl.style.display = 'none';

    fetch('/api/register_caretaker', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                messageEl.className = 'message success';
                messageEl.textContent = '✅ ' + data.message;
                messageEl.style.display = 'block';
                form.reset();
                loadCaretakers();

                // Hide message after 5 seconds
                setTimeout(() => {
                    messageEl.style.display = 'none';
                }, 5000);
            } else {
                messageEl.className = 'message error';
                messageEl.textContent = '❌ ' + (data.message || 'Registration failed');
                messageEl.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            messageEl.className = 'message error';
            messageEl.textContent = '❌ Error registering caretaker. Please try again.';
            messageEl.style.display = 'block';
        });
}

// Load all caretakers
function loadCaretakers() {
    const listEl = document.getElementById('caretakersList');
    listEl.innerHTML = '<p class="loading">Loading caretakers...</p>';

    fetch('/api/get_caretakers')
        .then(response => response.json())
        .then(data => {
            if (data.caretakers && data.caretakers.length > 0) {
                listEl.innerHTML = '';
                data.caretakers.forEach(caretaker => {
                    const item = createCaretakerItem(caretaker);
                    listEl.appendChild(item);
                });
            } else {
                listEl.innerHTML = `
                    <div class="empty-state">
                        <p>📭 No caretakers registered yet</p>
                        <p>Register a caretaker above to receive alerts</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading caretakers:', error);
            listEl.innerHTML = '<p class="loading">Error loading caretakers</p>';
        });
}

// Create caretaker item element
function createCaretakerItem(caretaker) {
    const item = document.createElement('div');
    item.className = `caretaker-item ${caretaker.is_active ? '' : 'inactive'}`;

    const registeredDate = new Date(caretaker.registered_at);
    const formattedDate = registeredDate.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    item.innerHTML = `
        <div class="caretaker-header">
            <div class="caretaker-name">${escapeHtml(caretaker.name)}</div>
            <span class="caretaker-status ${caretaker.is_active ? 'active' : 'inactive'}">
                ${caretaker.is_active ? '✓ Active' : '✗ Inactive'}
            </span>
        </div>
        <div class="caretaker-details">
            <div class="caretaker-detail">
                <strong>👤 Username:</strong>
                <span>${escapeHtml(caretaker.username || 'N/A')}</span>
            </div>
            <div class="caretaker-detail">
                <strong>📱 Mobile:</strong>
                <span>${escapeHtml(caretaker.mobile_number)}</span>
            </div>
            <div class="caretaker-detail">
                <strong>📧 Email:</strong>
                <span>${escapeHtml(caretaker.email)}</span>
            </div>
            <div class="caretaker-detail">
                <strong>📅 Registered:</strong>
                <span>${formattedDate}</span>
            </div>
        </div>
        <div class="caretaker-actions">
            <button class="btn btn-small ${caretaker.is_active ? 'btn-secondary' : 'btn-success'}" 
                    onclick="toggleCaretaker(${caretaker.id}, ${!caretaker.is_active})">
                ${caretaker.is_active ? 'Deactivate' : 'Activate'}
            </button>
            <button class="btn btn-danger btn-small" 
                    onclick="deleteCaretaker(${caretaker.id})">
                Delete
            </button>
        </div>
    `;

    return item;
}

// Toggle caretaker active status
function toggleCaretaker(caretakerId, isActive) {
    fetch(`/api/update_caretaker/${caretakerId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ is_active: isActive })
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                loadCaretakers();
            } else {
                alert('Error updating caretaker: ' + (data.message || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error updating caretaker');
        });
}

// Delete caretaker
function deleteCaretaker(caretakerId) {
    if (confirm('Are you sure you want to delete this caretaker? They will no longer receive alerts.')) {
        fetch(`/api/delete_caretaker/${caretakerId}`, {
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    loadCaretakers();
                } else {
                    alert('Error deleting caretaker: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error deleting caretaker');
            });
    }
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

