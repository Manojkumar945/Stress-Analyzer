// Caretaker Login JavaScript

document.addEventListener('DOMContentLoaded', function () {
    // Handle form submission
    document.getElementById('loginForm').addEventListener('submit', function (e) {
        e.preventDefault();
        loginCaretaker();
    });
});

// Login caretaker
function loginCaretaker() {
    const form = document.getElementById('loginForm');
    const loginValue = document.getElementById('username').value.trim().toLowerCase();
    const formData = {
        username: loginValue,
        email: loginValue, // Send as both to ensure backend catches it
        password: document.getElementById('password').value.trim()
    };

    // Show loading
    const messageEl = document.getElementById('message');
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;

    messageEl.className = 'message';
    messageEl.style.display = 'none';
    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in...';

    fetch('/api/caretaker_login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
        .then(response => response.json())
        .then(data => {
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;

            if (data.status === 'success') {
                messageEl.className = 'message success';
                messageEl.textContent = '✅ ' + data.message;
                messageEl.style.display = 'block';

                // Show caretaker info
                if (data.caretaker) {
                    const caretakerInfo = `
                    <div style="margin-top: 15px; padding: 15px; background: #f0f0f0; border-radius: 8px;">
                        <h3 style="margin: 0 0 10px 0; color: #333;">Logged in as:</h3>
                        <p style="margin: 5px 0;"><strong>Name:</strong> ${escapeHtml(data.caretaker.name)}</p>
                        <p style="margin: 5px 0;"><strong>Username:</strong> ${escapeHtml(data.caretaker.username)}</p>
                        <p style="margin: 5px 0;"><strong>Email:</strong> ${escapeHtml(data.caretaker.email)}</p>
                        <p style="margin: 5px 0;"><strong>Mobile:</strong> ${escapeHtml(data.caretaker.mobile_number)}</p>
                    </div>
                `;
                    messageEl.innerHTML = messageEl.textContent + caretakerInfo;
                }

                // Redirect to dashboard after 2 seconds
                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 2000);
            } else {
                messageEl.className = 'message error';
                messageEl.textContent = '❌ ' + (data.message || 'Login failed');
                messageEl.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
            messageEl.className = 'message error';
            messageEl.textContent = '❌ Error logging in. Please try again.';
            messageEl.style.display = 'block';
        });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

