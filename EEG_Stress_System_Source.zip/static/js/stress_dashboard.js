// Stress Dashboard JavaScript
let monitoringInterval = null;
let statusInterval = null;
let minutePredictionInterval = null;

// Store recent values for range calculation
let recentValues = {
    meanVal: [],
    stdVal: [],
    peakAmp: [],
    heartRate: [],
    rrVar: [],
    entropy: []
};

// Function to calculate range from recent values
function calculateRange(values, decimals = 1) {
    if (!values || values.length === 0) return '--';
    const validValues = values.filter(v => v !== null && v !== undefined && !isNaN(v));
    if (validValues.length === 0) return '--';
    const min = Math.min(...validValues);
    const max = Math.max(...validValues);
    if (min === max) {
        return min.toFixed(decimals).replace('.', ',');
    }
    return `${min.toFixed(decimals).replace('.', ',')} - ${max.toFixed(decimals).replace('.', ',')}`;
}

// Start monitoring
function startMonitoring() {
    fetch('/api/start_monitoring', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Monitoring started:', data);

            // Update button states
            document.getElementById('startBtn').disabled = true;
            document.getElementById('stopBtn').disabled = false;

            // Update status bar to show Monitoring Active
            const statusBar = document.getElementById('statusBar');
            statusBar.innerHTML = '<span>Status: <strong style="color: #28a745;">Monitoring Active</strong></span>';
            statusBar.style.background = '#d4edda';
            statusBar.style.borderLeft = '5px solid #28a745';

            // Start status updates (every second for real-time data)
            if (!statusInterval) {
                updateStatus(); // Update immediately
                statusInterval = setInterval(updateStatus, 1000);
            }

            // Start prediction updates (every 10 seconds)
            if (!minutePredictionInterval) {
                updateMinutePrediction(); // Update immediately
                minutePredictionInterval = setInterval(updateMinutePrediction, 10000); // Every 10 seconds
            }
        })
        .catch(error => {
            console.error('Error starting monitoring:', error);
            alert('❌ Error starting monitoring. Please check the console for details.');
        });
}

// Stop monitoring
function stopMonitoring() {
    fetch('/api/stop_monitoring', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Monitoring stopped:', data);

            // Update button states
            document.getElementById('startBtn').disabled = false;
            document.getElementById('stopBtn').disabled = true;

            // Update status bar to show Inactive
            const statusBar = document.getElementById('statusBar');
            statusBar.innerHTML = '<span>Status: <strong style="color: #666;">Inactive</strong></span>';
            statusBar.style.background = '#f8f9fa';
            statusBar.style.borderLeft = '5px solid #dee2e6';

            // Clear Extracted Features values when monitoring stops - show reference ranges
            recentValues = {
                meanVal: [],
                stdVal: [],
                peakAmp: [],
                heartRate: [],
                rrVar: [],
                entropy: []
            };
            document.getElementById('meanVal').textContent = '0,5 - 0,7';
            document.getElementById('stdVal').textContent = '0,1 - 0,2';
            document.getElementById('peakAmp').textContent = '50 - 100 μV';
            document.getElementById('heartRate').textContent = '70 - 90 bpm';
            document.getElementById('rrVar').textContent = '200 - 300 ms²';
            document.getElementById('entropy').textContent = '0,6 - 0,8';

            // Stop status updates
            if (statusInterval) {
                clearInterval(statusInterval);
                statusInterval = null;
            }

            // Stop minute prediction updates
            if (minutePredictionInterval) {
                clearInterval(minutePredictionInterval);
                minutePredictionInterval = null;
            }
        })
        .catch(error => {
            console.error('Error stopping monitoring:', error);
            alert('❌ Error stopping monitoring. Please check the console for details.');
        });
}

// Update prediction - analyzes second-by-second readings from the last minute (updates every 10 seconds)
function updateMinutePrediction() {
    fetch('/api/minute_prediction')
        .then(response => response.json())
        .then(data => {
            let prediction = null;
            let predictionText = '--';
            let predictionColor = '#666';

            if (data.prediction) {
                prediction = data.prediction.toLowerCase();
                predictionText = prediction.charAt(0).toUpperCase() + prediction.slice(1);

                // Set color based on prediction - brighter colors for visibility
                if (prediction === 'anxiety') {
                    predictionColor = '#ff0000'; // Bright Red
                } else if (prediction === 'stress') {
                    predictionColor = '#ff6600'; // Bright Orange
                } else {
                    predictionColor = '#00cc00'; // Bright Green for normal
                }

                // Update relaxation techniques based on prediction
                updateTechniquesByPrediction(prediction);
            } else {
                // If no prediction, show default techniques
                loadDefaultTechniques();
            }

            document.getElementById('predictionBar').innerHTML =
                `<span>Latest Prediction: <strong style="color: ${predictionColor};">${predictionText}</strong></span>`;
        })
        .catch(error => {
            console.error('Error fetching minute prediction:', error);
            // On error, show default techniques
            loadDefaultTechniques();
        });
}

// Update status display - runs every second for real-time updates
function updateStatus() {
    // Fetch status for therapy content
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            // Update therapy content
            if (data.therapy_content) {
                updateTherapyContent(data.therapy_content);
            }
        })
        .catch(error => console.error('Error fetching status:', error));

    // Fetch second-by-second features analysis
    fetch('/api/second_by_second_features')
        .then(response => response.json())
        .then(features => {
            // Update Extracted Features with ranges from second-by-second readings
            if (features.mean_range) {
                document.getElementById('meanVal').textContent = features.mean_range;
            } else {
                document.getElementById('meanVal').textContent = '0,5 - 0,7';
            }

            if (features.std_range) {
                document.getElementById('stdVal').textContent = features.std_range;
            } else {
                document.getElementById('stdVal').textContent = '0,1 - 0,2';
            }

            if (features.peak_range) {
                document.getElementById('peakAmp').textContent = `${features.peak_range} μV`;
            } else {
                document.getElementById('peakAmp').textContent = '50 - 100 μV';
            }

            if (features.hr_range) {
                document.getElementById('heartRate').textContent = `${features.hr_range} bpm`;
            } else {
                document.getElementById('heartRate').textContent = '70 - 90 bpm';
            }

            if (features.rr_range) {
                document.getElementById('rrVar').textContent = `${features.rr_range} ms²`;
            } else {
                document.getElementById('rrVar').textContent = '200 - 300 ms²';
            }

            if (features.entropy_range) {
                document.getElementById('entropy').textContent = features.entropy_range;
            } else {
                document.getElementById('entropy').textContent = '0,6 - 0,8';
            }
        })
        .catch(error => {
            console.error('Error fetching second-by-second features:', error);
            // Show reference ranges on error
            document.getElementById('meanVal').textContent = '0,5 - 0,7';
            document.getElementById('stdVal').textContent = '0,1 - 0,2';
            document.getElementById('peakAmp').textContent = '50 - 100 μV';
            document.getElementById('heartRate').textContent = '70 - 90 bpm';
            document.getElementById('rrVar').textContent = '200 - 300 ms²';
            document.getElementById('entropy').textContent = '0,6 - 0,8';
        });

    // Update second-by-second readings
    updateReadings();
}

// Update second-by-second readings table
function updateReadings() {
    fetch('/api/latest_readings')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('readingsTableBody');

            if (!data.readings || data.readings.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="loading">Waiting for data...</td></tr>';
                return;
            }

            // Show all readings from start to end (chronological order)
            // Data is already in chronological order from the API
            const displayReadings = data.readings;

            tbody.innerHTML = displayReadings.map((reading, index) => {
                const timestamp = new Date(reading.timestamp);
                const timeStr = timestamp.toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false
                });

                const prediction = reading.prediction || '--';
                let predictionBadge = '--';
                if (prediction !== '--') {
                    const predClass = prediction.toLowerCase();
                    predictionBadge = `<span class="prediction-badge ${predClass}">${prediction.toUpperCase()}</span>`;
                }

                return `<tr>
                    <td>${index + 1}</td>
                    <td>${timeStr}</td>
                    <td><strong>${reading.eeg_value.toFixed(2)}</strong></td>
                    <td>${predictionBadge}</td>
                    <td>${reading.heart_rate ? reading.heart_rate.toFixed(1) : '--'}</td>
                    <td>${reading.mean_val ? reading.mean_val.toFixed(2) : '--'}</td>
                    <td>${reading.std_val ? reading.std_val.toFixed(2) : '--'}</td>
                    <td>${reading.peak_amp ? reading.peak_amp.toFixed(2) : '--'}</td>
                </tr>`;
            }).join('');

            // Auto-scroll to bottom to show latest readings
            const container = document.querySelector('.readings-table-container');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        })
        .catch(error => {
            console.error('Error fetching readings:', error);
        });
}

// Format technique text - make technique name bold
function formatTechnique(tech) {
    if (tech.includes(':')) {
        const parts = tech.split(':');
        const name = parts[0].trim();
        const description = parts.slice(1).join(':').trim();
        return `<strong>${name}:</strong> ${description}`;
    }
    return tech;
}

// Update therapy content
function updateTherapyContent(therapy) {
    // Update relaxation techniques - display properly formatted
    const techniquesEl = document.getElementById('relaxationTechniques');
    if (therapy.techniques && therapy.techniques.length > 0) {
        techniquesEl.innerHTML = '<ul class="techniques-list" style="list-style-type: disc; padding-left: 20px; margin: 10px 0;">' +
            therapy.techniques.map(tech => `<li style="margin: 8px 0; color: #333; line-height: 1.6;">${formatTechnique(tech)}</li>`).join('') +
            '</ul>';
    } else {
        // Show default techniques if none provided
        loadDefaultTechniques();
    }

    // Update music player with clickable link
    if (therapy.songs && therapy.songs.length > 0) {
        const currentSongName = document.getElementById('currentSongName');
        const storedSong = sessionStorage.getItem('currentTherapySong');
        if (storedSong) {
            const song = JSON.parse(storedSong);
            if (song.url) {
                currentSongName.innerHTML = `🎵 <a href="${song.url}" target="_blank" style="color: #007bff; text-decoration: none; font-weight: 600;">${song.name}</a>`;
            } else {
                currentSongName.innerHTML = `🎵 ${song.name}`;
            }
        } else {
            currentSongName.textContent = 'No song selected';
        }
    }
}

// Load default techniques (Normal state)
function loadDefaultTechniques() {
    fetch('/api/therapy/normal')
        .then(response => response.json())
        .then(therapy => {
            const techniquesEl = document.getElementById('relaxationTechniques');
            if (therapy.techniques && therapy.techniques.length > 0) {
                techniquesEl.innerHTML = '<ul class="techniques-list" style="list-style-type: disc; padding-left: 20px; margin: 10px 0;">' +
                    therapy.techniques.map(tech => `<li style="margin: 8px 0; color: #333; line-height: 1.6;">${formatTechnique(tech)}</li>`).join('') +
                    '</ul>';
            }
        })
        .catch(error => {
            console.error('Error loading default techniques:', error);
            // Fallback message
            document.getElementById('relaxationTechniques').innerHTML =
                '<p style="color: #666; margin: 10px 0;">Waiting for monitoring data...</p>';
        });
}

// Update techniques based on prediction
function updateTechniquesByPrediction(prediction) {
    const predictionType = prediction ? prediction.toLowerCase() : 'normal';
    fetch(`/api/therapy/${predictionType}`)
        .then(response => response.json())
        .then(therapy => {
            const techniquesEl = document.getElementById('relaxationTechniques');
            if (therapy.techniques && therapy.techniques.length > 0) {
                techniquesEl.innerHTML = '<ul class="techniques-list" style="list-style-type: disc; padding-left: 20px; margin: 10px 0;">' +
                    therapy.techniques.map(tech => `<li style="margin: 8px 0; color: #333; line-height: 1.6;">${formatTechnique(tech)}</li>`).join('') +
                    '</ul>';
            }
        })
        .catch(error => {
            console.error('Error loading techniques for prediction:', error);
        });
}

// Play therapy music - changes song every time button is clicked and automatically plays
function playTherapy() {
    // Get current prediction for therapy type
    const currentPrediction = getCurrentPrediction();

    // Disable button temporarily to prevent multiple clicks
    const playBtn = document.querySelector('button[onclick="playTherapy()"]');
    const originalText = playBtn ? playBtn.textContent : 'Play Calming Music';
    if (playBtn) {
        playBtn.disabled = true;
        playBtn.textContent = 'Loading...';
    }

    fetch('/api/trigger_therapy', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            type: currentPrediction
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.song) {
                // Store song in session (will be different each time due to random.choice in backend)
                sessionStorage.setItem('currentTherapySong', JSON.stringify(data.song));
                sessionStorage.setItem('lastTherapyTime', Date.now().toString());

                // Update UI with new song name as clickable link
                const currentSongEl = document.getElementById('currentSongName');
                if (data.song.url) {
                    currentSongEl.innerHTML = `🎵 <a href="${data.song.url}" target="_blank" style="color: #007bff; text-decoration: none; font-weight: 600;">${data.song.name}</a>`;
                } else {
                    currentSongEl.innerHTML = `🎵 ${data.song.name}`;
                }

                // Automatically open and play the song in a new tab/window
                if (data.song.url) {
                    let songUrl = data.song.url;

                    // If it's a YouTube URL, add autoplay parameter
                    if (songUrl.includes('youtube.com') || songUrl.includes('youtu.be')) {
                        // Convert youtu.be to youtube.com format if needed
                        if (songUrl.includes('youtu.be/')) {
                            const videoId = songUrl.split('youtu.be/')[1].split('?')[0];
                            songUrl = `https://www.youtube.com/watch?v=${videoId}`;
                        }

                        // Add autoplay parameter if not already present
                        if (!songUrl.includes('autoplay=1')) {
                            songUrl += (songUrl.includes('?') ? '&' : '?') + 'autoplay=1';
                        }

                        console.log(`🎵 Opening and playing song: ${data.song.name}`);
                    }

                    // Open song URL in new window/tab - will automatically play
                    const songWindow = window.open(songUrl, '_blank', 'noopener,noreferrer');

                    // Focus the new window to bring it to front
                    if (songWindow) {
                        songWindow.focus();
                    }
                }

                // Update relaxation techniques - display properly formatted
                if (data.techniques && data.techniques.length > 0) {
                    const techniquesEl = document.getElementById('relaxationTechniques');
                    techniquesEl.innerHTML = '<ul class="techniques-list" style="list-style-type: disc; padding-left: 20px; margin: 10px 0;">' +
                        data.techniques.map(tech => `<li style="margin: 8px 0; color: #333; line-height: 1.6;">${formatTechnique(tech)}</li>`).join('') +
                        '</ul>';
                } else {
                    // Fallback: get techniques from therapy content
                    fetch(`/api/therapy/${currentPrediction}`)
                        .then(response => response.json())
                        .then(therapyData => {
                            if (therapyData.techniques && therapyData.techniques.length > 0) {
                                const techniquesEl = document.getElementById('relaxationTechniques');
                                techniquesEl.innerHTML = '<ul class="techniques-list" style="list-style-type: disc; padding-left: 20px; margin: 10px 0;">' +
                                    therapyData.techniques.map(tech => `<li style="margin: 8px 0; color: #333; line-height: 1.6;">${formatTechnique(tech)}</li>`).join('') +
                                    '</ul>';
                            }
                        })
                        .catch(err => console.error('Error fetching therapy techniques:', err));
                }

                // Show success message
                console.log(`🎵 New song selected and playing: ${data.song.name}`);

                // Re-enable button
                if (playBtn) {
                    playBtn.disabled = false;
                    playBtn.textContent = originalText;
                }
            } else {
                alert('⚠️ Could not load therapy content. Please try again.');
                if (playBtn) {
                    playBtn.disabled = false;
                    playBtn.textContent = originalText;
                }
            }
        })
        .catch(error => {
            console.error('Error triggering therapy:', error);
            alert('❌ Error loading therapy. Please check your connection and try again.');
            if (playBtn) {
                playBtn.disabled = false;
                playBtn.textContent = originalText;
            }
        });
}

// Get current prediction
function getCurrentPrediction() {
    const predictionBar = document.getElementById('predictionBar');
    const strong = predictionBar.querySelector('strong');
    if (strong) {
        return strong.textContent.toLowerCase();
    }
    return 'normal';
}

// Send test alert - sends instantly to all registered caretakers via Email and SMS
function sendTestAlert(buttonElement) {
    // Disable button to prevent multiple clicks
    const btn = buttonElement || document.getElementById('testAlertBtn');
    if (!btn) return;

    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Sending...';

    fetch('/api/send_alert', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            subject: '🚨 Test Alert - Brainwave Monitoring System',
            message: 'This is a test alert from the Brainwave Monitoring and Stress Alert System. The system is functioning normally. If you received this message, your contact information is properly configured.'
        })
    })
        .then(response => response.json())
        .then(data => {
            btn.disabled = false;
            btn.textContent = originalText;

            if (data.status === 'success') {
                let message = `✅ Test Alert Sent Successfully!\n\n`;
                message += `📧 Emails: ${data.email_count}/${data.total_caretakers} sent successfully\n`;
                message += `📱 SMS: ${data.sms_count}/${data.total_caretakers} sent successfully\n`;
                message += `👥 Total Caretakers: ${data.total_caretakers}\n\n`;

                if (data.email_failed > 0 || data.sms_failed > 0) {
                    message += `⚠️ Some notifications failed:\n`;
                    if (data.email_failed > 0) {
                        message += `- ${data.email_failed} email(s) failed\n`;
                    }
                    if (data.sms_failed > 0) {
                        message += `- ${data.sms_failed} SMS failed (SMS may not be configured)\n`;
                    }
                }

                if (data.total_caretakers === 0) {
                    message = `⚠️ No registered caretakers found in database.\n\nPlease register caretakers first using the "Manage Caretakers" button.`;
                }

                alert(message);
            } else {
                let errorMessage = `❌ Failed to send test alert.\n\n`;
                if (data.message) {
                    errorMessage += `${data.message}\n\n`;
                }
                errorMessage += `Please check:\n`;
                errorMessage += `1. Email configuration (EMAIL_ADDRESS and EMAIL_PASSWORD)\n`;
                errorMessage += `2. Caretaker registration in database\n`;
                errorMessage += `3. Network connectivity\n`;
                errorMessage += `4. Verify caretaker email and mobile number are correct in database`;
                alert(errorMessage);
            }
        })
        .catch(error => {
            console.error('Error sending alert:', error);
            btn.disabled = false;
            btn.textContent = originalText;
            alert('❌ Error sending test alert.\n\nPlease check:\n1. Server connection\n2. Email configuration\n3. Network connectivity');
        });
}

// Connection status is now tied to monitoring state, no need for separate check

// Initialize on page load
document.addEventListener('DOMContentLoaded', function () {
    // Load default techniques on page load
    loadDefaultTechniques();

    // Restore monitoring state from server
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            if (data.monitoring_active) {
                // Monitoring is active, restore button states and connection status
                document.getElementById('startBtn').disabled = true;
                document.getElementById('stopBtn').disabled = false;
                document.getElementById('statusBar').innerHTML =
                    '<span>Status: <strong style="color: #28a745;">Monitoring Active</strong></span>';
                document.getElementById('statusBar').style.background = '#d4edda';
                document.getElementById('statusBar').style.borderLeft = '5px solid #28a745';

                // Start prediction updates if monitoring is active (every 10 seconds)
                if (!minutePredictionInterval) {
                    updateMinutePrediction(); // Update immediately
                    minutePredictionInterval = setInterval(updateMinutePrediction, 10000); // Every 10 seconds
                }
            } else {
                // Monitoring is inactive
                document.getElementById('startBtn').disabled = false;
                document.getElementById('stopBtn').disabled = true;
                document.getElementById('statusBar').innerHTML =
                    '<span>Status: <strong>Inactive</strong></span>';
                document.getElementById('statusBar').style.background = '#f8f9fa';
                document.getElementById('statusBar').style.borderLeft = '5px solid #dee2e6';
            }

            // Start status updates (always running to show real-time data)
            updateStatus();
            if (!statusInterval) {
                statusInterval = setInterval(updateStatus, 1000);
            }
            setInterval(updateReadings, 1000);
        })
        .catch(error => {
            console.error('Error fetching initial status:', error);
            // Still start updates even if initial fetch fails
            updateStatus();
            if (!statusInterval) {
                statusInterval = setInterval(updateStatus, 1000);
            }
            setInterval(updateReadings, 1000);
        });

});

// Caretaker Management Functions

// Show/Hide Views
function showLoginView(e) {
    if (e) e.preventDefault();
    document.getElementById('caretakerLoginView').style.display = 'block';
    document.getElementById('caretakerRegisterView').style.display = 'none';
    document.getElementById('caretakerDashboardView').style.display = 'none';
}

function showRegisterView(e) {
    if (e) e.preventDefault();
    document.getElementById('caretakerLoginView').style.display = 'none';
    document.getElementById('caretakerRegisterView').style.display = 'block';
    document.getElementById('caretakerDashboardView').style.display = 'none';
}

function showDashboardView(caretakerName) {
    document.getElementById('caretakerLoginView').style.display = 'none';
    document.getElementById('caretakerRegisterView').style.display = 'none';
    document.getElementById('caretakerDashboardView').style.display = 'block';
    document.getElementById('caretakerNameDisplay').textContent = caretakerName;
    loadPatients();
}

// Handle Login
function handleCaretakerLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    fetch('/api/caretaker_login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                sessionStorage.setItem('caretaker', JSON.stringify(data.caretaker));
                showDashboardView(data.caretaker.name);
                alert('✅ Login successful!');
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            alert('❌ Login failed. Please try again.');
        });
}

// Handle Registration
function handleCaretakerRegister(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const mobile_number = document.getElementById('regMobile').value;
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regConfirmPassword').value;

    if (password !== confirmPassword) {
        alert('❌ Passwords do not match!');
        return;
    }

    // Auto-generate username from email (part before @)
    const username = email.split('@')[0];

    fetch('/api/register_caretaker', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            email,
            mobile_number,
            password,
            username // Backend requires username, generating from email
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('✅ Registration successful! Please login.');
                showLoginView();
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Registration error:', error);
            alert('❌ Registration failed. Please try again.');
        });
}

// Handle Logout
function handleCaretakerLogout() {
    fetch('/api/caretaker_logout', { method: 'POST' })
        .then(() => {
            sessionStorage.removeItem('caretaker');
            showLoginView();
        })
        .catch(error => console.error('Logout error:', error));
}

// Save Patient Details
function savePatientDetails(e) {
    e.preventDefault();
    const name = document.getElementById('patientName').value;
    const age = document.getElementById('patientAge').value;
    const gender = document.getElementById('patientGender').value;
    const medical_history = document.getElementById('medicalHistory').value;

    fetch('/api/add_patient', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            age,
            gender,
            medical_history
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('✅ Patient details saved successfully!');
                document.getElementById('patientForm').reset();
                loadPatients();
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error saving patient:', error);
            alert('❌ Failed to save patient details.');
        });
}

// Load Patients
function loadPatients() {
    const listEl = document.getElementById('patientsList');
    listEl.innerHTML = '<p class="loading">Loading patients...</p>';

    fetch('/api/get_patients')
        .then(response => response.json())
        .then(data => {
            if (data.patients && data.patients.length > 0) {
                listEl.innerHTML = data.patients.map(p => `
                <div class="patient-item">
                    <h5>${p.name}</h5>
                    <p><strong>Age:</strong> ${p.age || 'N/A'} | <strong>Gender:</strong> ${p.gender || 'N/A'}</p>
                    <p><strong>Medical History:</strong> ${p.medical_history || 'None'}</p>
                </div>
            `).join('');
            } else {
                listEl.innerHTML = '<p>No patients added yet.</p>';
            }
        })
        .catch(error => {
            console.error('Error loading patients:', error);
            listEl.innerHTML = '<p>Error loading patients.</p>';
        });
}

// Check login status on load
// Note: DOMContentLoaded listener is already present in the file, we should append this check inside it or add a new one.
// Since we are appending to the end, adding a new listener is safer.
document.addEventListener('DOMContentLoaded', function () {
    // Check if caretaker is logged in
    const storedCaretaker = sessionStorage.getItem('caretaker');
    if (storedCaretaker) {
        const caretaker = JSON.parse(storedCaretaker);
        showDashboardView(caretaker.name);
    } else {
        showLoginView();
    }
});


